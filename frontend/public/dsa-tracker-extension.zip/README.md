# ⚡ DSA Tracker Chrome Extension (Auto-Capture)

Auto-captures your code, runtime, and memory whenever you get **Accepted** on **LeetCode** or **GeeksForGeeks**, and automatically syncs it with your **DSA Tracker Cloud**!

---

### 🚀 How to Install in 30 Seconds:

1. **Open Chrome / Brave / Edge** and type this in your URL bar:
   ```text
   chrome://extensions
   ```
2. Top-right corner mein **"Developer mode"** toggle ko **ON** karein.
3. Top-left corner mein **"Load unpacked"** button par click karein.
4. Yeh folder select karein:
   ```text
   C:\CORE SUBJECT\best\dsa\extension
   ```
5. Done! Extension install ho jayegi.

---

### ⚙️ Quick Setup:

1. Chrome toolbar mein extension icon (⚡) par click karein.
2. Apna **Sync Key** daalein (jaise aap website par use karte hain).
3. **Backend API** select karein:
   - **Live Cloud (Render)** ➔ Default `https://dsa-plan-backend.onrender.com`
   - **Localhost** ➔ Jab aap local port 5000 par run kar rahe hon.
4. Click **"Save Settings"**.

---

### 🎯 How it Works:
- Jab bhi aap LeetCode ya GFG par koi question solve karke **"Submit"** karenge aur **"Accepted"** aayega:
  - Extension screen ke bottom-right par ek floating banner dikhayegi:
    `🚀 DSA Tracker Cloud Sync: [Problem Name] Synced!`
  - Code, runtime, memory, aur completion date turant aapke **MongoDB Atlas Database** mein store ho jayegi.
  - Tracker website kholne par wo problem automatically **Solved & Scheduled for Revision** dikhega!
